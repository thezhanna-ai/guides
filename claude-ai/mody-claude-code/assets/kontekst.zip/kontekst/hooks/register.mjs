// kontekst: полоса над полем ввода, сколько контекста занято
//
// Мод ничего не отправляет в сеть и не вызывает модель
// Он читает $.session.usage() - те же цифры, что показывает строка состояния
// Показывать расход не значит экономить: мод только показывает

// Последнее показание: { tokens, window, percent } или null
let reading = null

export function register(on) {
  on('session.start', async ($, e, next) => {
    const result = await next(e)
    reading = null
    await takeReading($)
    return result
  })

  // После каждого хода основного диалога, ходы субагентов пропускаем
  on('turn.complete', async ($, e, next) => {
    const result = await next(e)
    if (!e.agentId) await takeReading($)
    return result
  })

  on('ui.render', { component: 'AbovePrompt' }, async ($, e, next) => {
    const props = e.props ?? {}
    if (props.hasSurvey || reading === null) return next(e)
    const beneath = await next(e)
    const { Box, Text } = $.ui.resolve(e)
    const line = bandLine(Text, reading)
    const children = isBlank(beneath) ? [line] : [beneath, line]
    return Box({ key: 'kontekst', flexDirection: 'column', children })
  })
}

async function takeReading($) {
  try {
    const { context } = await $.session.usage()
    // До первого ответа модели цифры нет, полосу не рисуем
    if (!context || !context.window || context.tokens === undefined) return
    const tokens = context.tokens
    const percent = Math.round(context.percent ?? (tokens / context.window) * 100)
    reading = { tokens, window: context.window, percent }
    $.ui.invalidate('ui.render')
  } catch {
    // Показания нет, полоса оставляет прежнее
  }
}

// Текст полосы, отдельно от отрисовки, чтобы его было легко проверить
export function describe({ tokens, window, percent }) {
  const amount = `${percent}% (${thousands(tokens)} из ${thousands(window)} токенов)`
  if (percent >= 75) return { text: `Контекст занят на ${amount} - пора /compact или новая сессия`, color: 'error' }
  if (percent >= 50) return { text: `Контекст занят на ${amount} - скоро стоит сделать /compact`, color: 'warning' }
  return { text: `Контекст занят на ${amount} - места хватает`, color: undefined }
}

function bandLine(Text, r) {
  const { text, color } = describe(r)
  return color ? Text({ color, children: text }) : Text({ dimColor: true, children: text })
}

export function thousands(n) {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1).replace('.', ',')} млн`
  if (n >= 1_000) return `${Math.round(n / 1_000)} тыс.`
  return String(n)
}

function isBlank(node) {
  if (node === undefined || node === null) return true
  if (typeof node === 'string') return node.trim() === ''
  return (node.type === 'Box' || node.type === 'Text') && (node.children ?? []).every(isBlank)
}

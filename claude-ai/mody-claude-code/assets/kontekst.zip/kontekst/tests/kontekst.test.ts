import { expect, test } from 'claude-code/testing'
import { describe, thousands } from '../hooks/register.mjs'

const WINDOW = 200_000
const BAND = { hasSurvey: false, isWorking: false, maxRows: 20, bodyColumns: 80, scroll: { offset: 0, bodyRows: 20 }, view: {} }

function stubs(on: any, percent: number | undefined) {
  const context = percent === undefined ? { window: WINDOW } : { window: WINDOW, tokens: (WINDOW * percent) / 100, percent }
  on('session.start', ($: any, e: any) => ({ cwd: e.cwd }))
  on('session.usage', () => ({ value: { startedAt: 0, context, rateLimits: [] } }))
  on('ui.render', () => ({ type: 'Box', props: {}, children: [] }))
}

const start = ($: any) => $.session.start({ cwd: '/project', surface: 'terminal', isInteractive: true })
const band = ($: any) => $.ui.mount({ plugin: 'kontekst', surface: 'terminal', component: 'AbovePrompt', props: BAND })

test('мод загружается и рисует полосу после старта сессии', async ($, on) => {
  stubs(on, 30)
  await start($)
  const ui = await band($)
  expect(await ui.find({ type: 'Text', text: 'Контекст занят на 30% (60 тыс. из 200 тыс. токенов) - места хватает' })).toBeDefined()
})

test('при 80% полоса красная и советует /compact', async ($, on) => {
  stubs(on, 80)
  await start($)
  const ui = await band($)
  expect(await ui.find({ type: 'Text', text: /пора \/compact/ })).toMatchObject({ props: { color: 'error' } })
})

test('без цифр контекста полоса ничего не рисует', async ($, on) => {
  stubs(on, undefined)
  await start($)
  const ui = await band($)
  expect(await ui.find({ type: 'Text', text: /Контекст/ })).toBeUndefined()
})

test('пороги и запись чисел', () => {
  expect(describe({ tokens: 116_000, window: 200_000, percent: 58 }).color).toBe('warning')
  expect(describe({ tokens: 10_000, window: 200_000, percent: 5 }).color).toBeUndefined()
  expect(thousands(1_000_000)).toBe('1,0 млн')
  expect(thousands(950)).toBe('950')
})

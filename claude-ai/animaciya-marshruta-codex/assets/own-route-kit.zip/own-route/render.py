"""Run in this folder: python render.py --preview, then python render.py"""
import json,math,sys,subprocess as sp
from pathlib import Path
from PIL import Image,ImageDraw
D=Path(__file__).resolve().parent
cfg=json.loads((D/'route.json').read_text(encoding='utf8'))
im=Image.open(D/cfg['map']).convert('RGB');w,h=im.size
pts=cfg['points'];assert len(pts)>=2 and all(0<=x<w and 0<=y<h for x,y in pts)
length=[math.dist(a,b) for a,b in zip(pts,pts[1:])];assert min(length)>0
W,H=1280,720; scale=min(W/w,H/h)
# Keep the complete icon on screen even when a waypoint touches the image edge.
if any((W-w*scale)/2+x*scale<42 or (W-w*scale)/2+x*scale>W-42 or (H-h*scale)/2+y*scale<86 or (H-h*scale)/2+y*scale>H-5 for x,y in pts):
 scale=min((W-2*44)/w,(H-2*88)/h)
nw,nh=round(w*scale),round(h*scale);base=Image.new('RGB',(W,H),'#f6f2e8');base.paste(im.resize((nw,nh),Image.Resampling.LANCZOS),((W-nw)//2,(H-nh)//2));points=[((W-nw)//2+x*scale,(H-nh)//2+y*scale) for x,y in pts]
secs=float(cfg['seconds']);assert 1<=secs<=120
icon=Image.open(D/cfg['icon']).convert('RGBA') if cfg.get('icon') else None
if icon:icon.thumbnail((76,84))
def frame(f):
 pic=base.copy();d=ImageDraw.Draw(pic);remaining=f*sum(length);done=[points[0]]
 for i,l in enumerate(length):
  a,b=points[i:i+2];u=min(1,remaining/l);x,y=[a[j]+(b[j]-a[j])*u for j in (0,1)];done.append((x,y))
  if remaining<=l:break
  remaining-=l
 d.line(points,fill='#b3c7ba',width=6,joint='curve');d.line(done,fill='#147962',width=9,joint='curve')
 if icon:pic.paste(icon,(round(x-icon.width/2),round(y-icon.height)),icon)
 else:
  swing=math.sin(f*sum(length)/20);dx=9*swing
  d.ellipse((x-17,y-4,x+17,y+4),fill='#9cae9e')
  for sign,col in [(-1,'#5b6865'),(1,'#203a37')]:
   d.line([(x,y-25),(x+sign*dx,y-13),(x+sign*dx*1.35,y)],fill=col,width=6)
  d.line((x,y-42,x,y-24),fill='#db5130',width=15);d.line((x,y-39,x-dx,y-26),fill='#a94229',width=5);d.ellipse((x-7,y-57,x+7,y-43),fill='#46372f')
 return pic
if '--preview' in sys.argv:
 frame(1).save(D/'preview.png');sys.exit()
out=D/'my-route.mp4'
if out.exists():raise SystemExit('my-route.mp4 уже существует. Сохрани новую версию в отдельной копии папки.')
fps=25;count=round(fps*secs);proc=sp.Popen(['ffmpeg','-v','error','-n','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r',str(fps),'-i','-','-c:v','libx264','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],stdin=sp.PIPE)
for n in range(count):proc.stdin.write(frame(n/(count-1)).tobytes())
proc.stdin.close();sys.exit(proc.wait())

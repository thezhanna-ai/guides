import fs from 'node:fs';
const r=JSON.parse(fs.readFileSync(new URL('route.json',import.meta.url),'utf8'));
if(!Number.isFinite(r.tripSeconds)||r.tripSeconds<2||r.tripSeconds>12)throw Error('tripSeconds: от 2 до 12 секунд');
if(!Array.isArray(r.points)||r.points.length<2||r.points.some(p=>!Array.isArray(p)||p.length!==2||p.some(x=>!Number.isFinite(x))||p[0]<96||p[0]>1824||p[1]<54||p[1]>1026))throw Error('points: нужны точки внутри карты 1920x1080');
for(const k of ['title','startLabel','finishLabel'])if(typeof r[k]!=='string'||!r[k].trim()||r[k].length>25)throw Error(k+': от 1 до 25 знаков');
fs.writeFileSync(new URL('assets/route-config.js',import.meta.url),'window.BIKE_ROUTE='+JSON.stringify(r)+';\n');
console.log('Маршрут подготовлен: '+r.points.length+' точки, движение '+r.tripSeconds+' с');
